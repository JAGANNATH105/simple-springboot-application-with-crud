package com.aerospike.demo.simplespringbootaerospikedemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpleSpringbootAerospikeDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
